# CPSC350_SP21_ASSIGNMENT6_CARUTHERSANDGUARNOTTA

1. Sophia Guarnotta

  2369941

  Sarah Caruthers

  2350081

  CPSC 350-03

  Programming Assignment 6: Building a Database with Binary Search Trees

2. BST.h

   DLList.h

   DLLStack.h

   Faculty.h

   Faculty.cpp

   Simulation.h

   Simulation.cpp

   Student.h

   Student.cpp

   main.cpp

3. For this assignment we talked to Jessica Viner about using a stack for the rollback method. We also added graduation year for students because we thought we were supposed to include it. The damage was already done by the time we realized we didn't need it :).

4. For this assignment we referenced https://www.geeksforgeeks.org/stdto_string-in-cpp/ and https://www.tutorialspoint.com/cplusplus/cpp_overloading.htm

5. make

  ./assignment6.exe
