#include "Simulation.h"

using namespace std;

/*
 * Main method for assignment 6
 * makes a simulation object and calls simulate
 */
int main(){
  Simulation s1;
  s1.simulate();
  return 0;
}
